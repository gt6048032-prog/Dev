// =============================================================================
//  Star Universe — script.js
//  Touch fix: e.preventDefault() on touchend blocks the browser's fake click.
//  A lastTouchTime guard also catches any synthetic click that slips through.
// =============================================================================

// ─── Elements ─────────────────────────────────────────────────────────────────
var canvas         = document.getElementById('universe');
var ctx            = canvas.getContext('2d');
var instruction    = document.getElementById('instruction');
var nowPlaying     = document.getElementById('now-playing');
var npTitle        = document.getElementById('np-title');
var stopBtn        = document.getElementById('stop-btn');
var npDeleteBtn    = document.getElementById('np-delete-btn');
var uploadBtn      = document.getElementById('upload-btn');
var fileInput      = document.getElementById('file-input');
var mediaOverlay   = document.getElementById('media-overlay');
var mediaContent   = document.getElementById('media-content');
var mediaTitle     = document.getElementById('media-title');
var mediaClose     = document.getElementById('media-close');
var mediaDeleteBtn = document.getElementById('media-delete-btn');
var nameDialog     = document.getElementById('name-dialog');
var nameDialogTitle= document.getElementById('name-dialog-title');
var nameFields     = document.getElementById('name-fields');
var nameCancelBtn  = document.getElementById('name-cancel-btn');
var nameConfirmBtn = document.getElementById('name-confirm-btn');
var confirmPopup   = document.getElementById('confirm-popup');
var confirmText    = document.getElementById('confirm-text');
var confirmYes     = document.getElementById('confirm-yes');
var confirmNo      = document.getElementById('confirm-no');

// ─── Canvas size ──────────────────────────────────────────────────────────────
var W = canvas.width  = window.innerWidth;
var H = canvas.height = window.innerHeight;

window.addEventListener('resize', function () {
  W = canvas.width  = window.innerWidth;
  H = canvas.height = window.innerHeight;
  initComets();
});

// ─── Global state ─────────────────────────────────────────────────────────────
var stars        = [];
var comets       = [];
var ripples      = [];
var labels       = [];
var mouse        = { x: 0, y: 0, tx: 0, ty: 0 };
var audioEl      = new Audio();
var playingId    = null;   // id of the star whose audio is playing
var openMediaId  = null;   // id of the star shown in the media overlay
var hasUploaded  = false;
var time         = 0;

// Delete state
var pendingDeleteId = null;
var longPressTimer  = null;

// ── Touch double-fire guard ───────────────────────────────────────────────────
var lastTouchTime = 0;

// Pending files for the naming dialog
var pendingFiles  = [];

// ─── Type colours ─────────────────────────────────────────────────────────────
var TYPE_COLOR  = { audio: '#a78bfa', image: '#38bdf8', video: '#fb923c' };
var TYPE_GLOW   = { audio: 'rgba(167,139,250,', image: 'rgba(56,189,248,', video: 'rgba(251,146,60,' };
var TYPE_LITE   = { audio: '#ddd6fe',  image: '#bae6fd',  video: '#fed7aa' };
var TYPE_ICON   = { audio: '\u266a',   image: '\u25a0',   video: '\u25b6' };  // ♪ ■ ▶

// ─── Helpers ──────────────────────────────────────────────────────────────────
function rand(a, b) { return Math.random() * (b - a) + a; }
function uid()      { return Math.random().toString(36).slice(2, 9); }

function getType(file) {
  if (file.type.startsWith('audio/')) return 'audio';
  if (file.type.startsWith('image/')) return 'image';
  if (file.type.startsWith('video/')) return 'video';
  return null;
}

function getStarById(id) {
  for (var i = 0; i < stars.length; i++) if (stars[i].id === id) return stars[i];
  return null;
}

function starAtPoint(mx, my) {
  for (var i = 0; i < stars.length; i++) {
    var s  = stars[i];
    var px = s.x * W + mouse.x * s.z * 40;
    var py = s.y * H + mouse.y * s.z * 40;
    if (Math.hypot(px - mx, py - my) < 32) return s;
  }
  return null;
}

// ─── Stars ────────────────────────────────────────────────────────────────────
function makeStar(id, name, url, type) {
  return {
    id: id, name: name, objectUrl: url, type: type,
    x: rand(0.06, 0.94), y: rand(0.06, 0.94), z: rand(0.3, 1),
    baseSize: rand(2.5, 4.5),
    twinkleSpeed: rand(0.01, 0.04),
    twinklePhase: rand(0, Math.PI * 2),
    hasOpened: false
  };
}

// ─── Comets ───────────────────────────────────────────────────────────────────
function makeComet() {
  return {
    x: rand(-W * 0.2, W * 1.1), y: rand(-H * 0.1, H * 0.6),
    speed: rand(3, 7), angle: rand(20, 45) * Math.PI / 180,
    length: rand(60, 140), alpha: 0, life: 0, maxLife: rand(80, 160),
    size: rand(0.8, 1.5)
  };
}

function initComets() {
  comets = [];
  for (var i = 0; i < 6; i++) {
    var c = makeComet(); c.life = rand(0, c.maxLife); comets.push(c);
  }
}
initComets();

function drawComets() {
  for (var i = 0; i < comets.length; i++) {
    var c = comets[i];
    c.life++; c.x += Math.cos(c.angle) * c.speed; c.y += Math.sin(c.angle) * c.speed;
    var p = c.life / c.maxLife;
    c.alpha = p < 0.15 ? p / 0.15 : p > 0.75 ? 1 - (p - 0.75) / 0.25 : 1;
    var tx = c.x - Math.cos(c.angle) * c.length;
    var ty = c.y - Math.sin(c.angle) * c.length;
    var g  = ctx.createLinearGradient(tx, ty, c.x, c.y);
    g.addColorStop(0, 'rgba(255,255,255,0)');
    g.addColorStop(1, 'rgba(255,255,255,' + (c.alpha * 0.7) + ')');
    ctx.save();
    ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(c.x, c.y);
    ctx.strokeStyle = g; ctx.lineWidth = c.size; ctx.stroke();
    ctx.beginPath(); ctx.arc(c.x, c.y, c.size * 1.5, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,' + (c.alpha * 0.9) + ')'; ctx.fill();
    ctx.restore();
    if (c.life >= c.maxLife || c.x > W * 1.2 || c.y > H * 1.2) {
      comets[i] = makeComet();
    }
  }
}

// ─── Nebula ───────────────────────────────────────────────────────────────────
function drawNebula(cx, cy, r, col) {
  var g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
  g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}

// ─── Audio ────────────────────────────────────────────────────────────────────
audioEl.addEventListener('ended', stopAudio);

function stopAudio() {
  audioEl.pause(); audioEl.src = '';
  playingId = null;
  nowPlaying.classList.remove('visible');
}

stopBtn.addEventListener('click', function (e) {
  e.stopPropagation(); stopAudio();
});

// Delete from Now Playing bar
npDeleteBtn.addEventListener('click', function (e) {
  e.stopPropagation();
  if (!playingId) return;
  var s = getStarById(playingId);
  if (s) showConfirmAt(s.name, s.id, W / 2, H - 90);
});

// ─── Media overlay ────────────────────────────────────────────────────────────
function openMedia(star) {
  if (playingId) stopAudio();
  openMediaId  = star.id;
  star.hasOpened = true;
  mediaContent.innerHTML = '';

  if (star.type === 'image') {
    var img = document.createElement('img');
    img.src = star.objectUrl; img.alt = star.name;
    mediaContent.appendChild(img);
  } else {
    var vid = document.createElement('video');
    vid.src = star.objectUrl; vid.controls = true;
    mediaContent.appendChild(vid);
    vid.play().catch(function () { });
  }

  mediaTitle.textContent = star.name;
  mediaOverlay.classList.remove('hidden');
}

function closeMedia() {
  var vid = mediaContent.querySelector('video');
  if (vid) { vid.pause(); vid.src = ''; }
  mediaContent.innerHTML = '';
  mediaOverlay.classList.add('hidden');
  openMediaId = null;
}

mediaClose.addEventListener('click', closeMedia);

mediaOverlay.addEventListener('click', function (e) {
  if (e.target === mediaOverlay) closeMedia();
});

mediaContent.addEventListener('click', function (e) { e.stopPropagation(); });

mediaDeleteBtn.addEventListener('click', function () {
  if (openMediaId) {
    var id = openMediaId;
    closeMedia();
    deleteStar(id);
  }
});

// ─── Play / open a star ───────────────────────────────────────────────────────
function playStar(star) {
  if (star.type === 'image' || star.type === 'video') {
    openMedia(star);
    return;
  }

  // Audio — toggle if tapped while already playing
  if (playingId === star.id && !audioEl.paused) {
    stopAudio(); return;
  }
  audioEl.pause();
  audioEl.src    = star.objectUrl;
  audioEl.play().catch(function () {});
  playingId      = star.id;
  star.hasOpened = true;

  var px = star.x * W + mouse.x * star.z * 40;
  var py = star.y * H + mouse.y * star.z * 40;
  ripples.push({ x: px, y: py, r: 4, alpha: 1 });
  ripples.push({ x: px, y: py, r: 4, alpha: 0.7, delay: 8 });
  labels.push({ text: star.name, x: px, y: py - 42, alpha: 1, born: Date.now() });

  npTitle.textContent = star.name;
  nowPlaying.classList.add('visible');
}

// ─── Naming dialog ────────────────────────────────────────────────────────────
uploadBtn.addEventListener('click', function () { fileInput.click(); });

fileInput.addEventListener('change', function (e) {
  var valid = Array.from(e.target.files).filter(function (f) { return getType(f); });
  fileInput.value = '';
  if (!valid.length) return;
  pendingFiles = valid;
  showNameDialog(valid);
});

function showNameDialog(files) {
  nameFields.innerHTML = '';
  nameDialogTitle.textContent = files.length === 1 ? 'Name your star' : 'Name your ' + files.length + ' stars';

  files.forEach(function (file, i) {
    var type  = getType(file);
    var defName = file.name.replace(/\.[^/.]+$/, '');

    var row  = document.createElement('div'); row.className = 'name-row';
    var icon = document.createElement('span');
    icon.className   = 'name-row-icon ' + type;
    icon.textContent = TYPE_ICON[type] || '\u2605';

    var inp  = document.createElement('input');
    inp.type        = 'text';
    inp.value       = defName;
    inp.placeholder = 'Star name\u2026';
    inp.maxLength   = 60;

    inp.addEventListener('focus', function () { this.select(); });
    inp.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Enter') return;
      ev.preventDefault();
      var all  = nameFields.querySelectorAll('input');
      var next = all[i + 1];
      if (next) next.focus(); else confirmNames();
    });

    row.appendChild(icon); row.appendChild(inp);
    nameFields.appendChild(row);
  });

  nameDialog.classList.remove('hidden');
  var first = nameFields.querySelector('input');
  if (first) setTimeout(function () { first.focus(); }, 80);
}

function confirmNames() {
  var inputs = nameFields.querySelectorAll('input');
  if (!hasUploaded) { hasUploaded = true; instruction.classList.add('hidden'); }

  pendingFiles.forEach(function (file, i) {
    var raw  = inputs[i] ? inputs[i].value.trim() : '';
    var name = raw || file.name.replace(/\.[^/.]+$/, '');
    stars.push(makeStar(uid(), name, URL.createObjectURL(file), getType(file)));
  });

  pendingFiles = [];
  nameDialog.classList.add('hidden');
}

function cancelNameDialog() { pendingFiles = []; nameDialog.classList.add('hidden'); }

nameConfirmBtn.addEventListener('click', confirmNames);
nameCancelBtn.addEventListener('click',  cancelNameDialog);
nameDialog.addEventListener('click', function (e) { if (e.target === nameDialog) cancelNameDialog(); });

// ─── Delete ───────────────────────────────────────────────────────────────────
function showConfirmAt(name, id, anchorX, anchorY) {
  pendingDeleteId = id;
  confirmText.textContent = 'Delete "' + name + '"?';
  confirmPopup.classList.remove('hidden');
  var pw = confirmPopup.offsetWidth  || 220;
  var ph = confirmPopup.offsetHeight || 96;
  confirmPopup.style.left = Math.max(10, Math.min(anchorX - pw / 2, W - pw - 10)) + 'px';
  confirmPopup.style.top  = Math.max(10, Math.min(anchorY - ph - 20, H - ph - 10)) + 'px';
}

function hideConfirm() { confirmPopup.classList.add('hidden'); pendingDeleteId = null; }

function deleteStar(id) {
  if (playingId === id) stopAudio();
  if (openMediaId === id) closeMedia();
  for (var i = 0; i < stars.length; i++) {
    if (stars[i].id === id) { URL.revokeObjectURL(stars[i].objectUrl); stars.splice(i, 1); break; }
  }
  if (stars.length === 0) {
    hasUploaded = false;
    instruction.classList.remove('hidden');
    setTimeout(function () { instruction.classList.add('hidden'); }, 6000);
  }
  hideConfirm();
}

confirmYes.addEventListener('click', function () { if (pendingDeleteId) deleteStar(pendingDeleteId); });
confirmNo.addEventListener('click',  hideConfirm);

canvas.addEventListener('contextmenu', function (e) {
  e.preventDefault();
  var s = starAtPoint(e.clientX, e.clientY);
  if (s) showConfirmAt(s.name, s.id, e.clientX, e.clientY);
});

// ─── Touch handling (mobile) ──────────────────────────────────────────────────
canvas.addEventListener('touchstart', function (e) {
  var t = e.touches[0];
  mouse.tx = (t.clientX / W) * 2 - 1;
  mouse.ty = (t.clientY / H) * 2 - 1;

  var mx = t.clientX, my = t.clientY;
  longPressTimer = setTimeout(function () {
    longPressTimer = null;
    lastTouchTime  = Date.now();
    var s = starAtPoint(mx, my);
    if (s) showConfirmAt(s.name, s.id, mx, my);
  }, 600);
}, { passive: true });

canvas.addEventListener('touchend', function (e) {
  if (!longPressTimer) return;
  clearTimeout(longPressTimer);
  longPressTimer = null;

  e.preventDefault();
  lastTouchTime = Date.now();

  if (!confirmPopup.classList.contains('hidden')) { hideConfirm(); return; }
  if (!mediaOverlay.classList.contains('hidden'))  { closeMedia();  return; }

  var t = e.changedTouches[0];
  var s = starAtPoint(t.clientX, t.clientY);
  if (s) playStar(s);
});

canvas.addEventListener('touchmove', function (e) {
  if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; }
  var t = e.touches[0];
  mouse.tx = (t.clientX / W) * 2 - 1;
  mouse.ty = (t.clientY / H) * 2 - 1;
}, { passive: true });

canvas.addEventListener('touchcancel', function () {
  if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; }
});

// ─── Mouse click (desktop) ────────────────────────────────────────────────────
canvas.addEventListener('click', function (e) {
  if (Date.now() - lastTouchTime < 600) return;

  if (!confirmPopup.classList.contains('hidden')) { hideConfirm(); return; }
  if (!mediaOverlay.classList.contains('hidden'))  return;

  var s = starAtPoint(e.clientX, e.clientY);
  if (s) playStar(s);
});

window.addEventListener('mousemove', function (e) {
  mouse.tx = (e.clientX / W) * 2 - 1;
  mouse.ty = (e.clientY / H) * 2 - 1;
});

setTimeout(function () { instruction.classList.add('hidden'); }, 6000);

// ─── Render loop ──────────────────────────────────────────────────────────────
function render() {
  time++;
  mouse.x += (mouse.tx - mouse.x) * 0.05;
  mouse.y += (mouse.ty - mouse.y) * 0.05;

  ctx.fillStyle = '#05030f';
  ctx.fillRect(0, 0, W, H);

  drawNebula(W * 0.2 + mouse.x * 20, H * 0.3 + mouse.y * 20, W * 0.6, 'rgba(40,20,80,0.28)');
  drawNebula(W * 0.8 + mouse.x * 30, H * 0.7 + mouse.y * 30, W * 0.5, 'rgba(20,40,90,0.18)');
  drawNebula(W * 0.5 + mouse.x * 10, H * 0.1 + mouse.y * 10, W * 0.3, 'rgba(60,10,60,0.12)');

  drawComets();

  for (var i = ripples.length - 1; i >= 0; i--) {
    var rp = ripples[i];
    if (rp.delay && rp.delay > 0) { rp.delay--; continue; }
    rp.r += 2.5; rp.alpha -= 0.016;
    if (rp.alpha <= 0) { ripples.splice(i, 1); continue; }
    ctx.beginPath(); ctx.arc(rp.x, rp.y, rp.r, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255,255,255,' + (rp.alpha * 0.45) + ')';
    ctx.lineWidth = 1.5; ctx.stroke();
    ctx.beginPath(); ctx.arc(rp.x, rp.y, rp.r * 0.75, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(167,139,250,' + (rp.alpha * 0.3) + ')';
    ctx.lineWidth = 3; ctx.stroke();
  }

  for (var j = 0; j < stars.length; j++) {
    var star    = stars[j];
    var px      = star.x * W + mouse.x * star.z * 40;
    var py      = star.y * H + mouse.y * star.z * 40;
    var twinkle = Math.sin(time * star.twinkleSpeed + star.twinklePhase) * 0.5 + 0.5;
    var size    = star.baseSize * (0.85 + twinkle * 0.3);
    var playing = playingId   === star.id;
    var isOpen  = openMediaId === star.id;
    var isPdel  = pendingDeleteId === star.id;

    var glowCol  = isPdel ? 'rgba(252,165,165,' : TYPE_GLOW[star.type];
    var coreCol  = isPdel ? '#fca5a5' : star.hasOpened ? TYPE_LITE[star.type] : '#ffffff';
    var glowR    = (playing || isOpen) ? size * 7 : size * 3.5;
    var glowAlp  = (playing || isOpen) ? 0.9 : 0.5 + twinkle * 0.2;

    var glow = ctx.createRadialGradient(px, py, 0, px, py, glowR);
    glow.addColorStop(0,    'rgba(255,255,255,' + glowAlp + ')');
    glow.addColorStop(0.25, glowCol + (glowAlp * 0.75) + ')');
    glow.addColorStop(1,    glowCol + '0)');

    ctx.beginPath(); ctx.arc(px, py, glowR, 0, Math.PI * 2);
    ctx.fillStyle = glow; ctx.fill();

    ctx.beginPath(); ctx.arc(px, py, size, 0, Math.PI * 2);
    ctx.fillStyle = coreCol; ctx.fill();

    ctx.beginPath(); ctx.arc(px, py + size + 4, size * 0.42, 0, Math.PI * 2);
    ctx.fillStyle = TYPE_COLOR[star.type]; ctx.fill();

    if (playing) {
      var pulse = Math.sin(time * 0.1) * 0.5 + 0.5;
      ctx.beginPath(); ctx.arc(px, py, size * (2 + pulse * 2.5), 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,255,' + (0.18 * (1 - pulse)) + ')'; ctx.fill();
    }

    if (isOpen) {
      ctx.beginPath(); ctx.arc(px, py, size * 3.8, 0, Math.PI * 2);
      ctx.strokeStyle = glowCol + '0.5)'; ctx.lineWidth = 1; ctx.stroke();
    }
  }

  var now = Date.now();
  for (var k = labels.length - 1; k >= 0; k--) {
    var lb  = labels[k];
    var age = now - lb.born;
    lb.y -= 0.25;
    if (age > 2000) lb.alpha = Math.max(0, 1 - (age - 2000) / 1000);
    if (lb.alpha <= 0) { labels.splice(k, 1); continue; }
    ctx.font = '13px Outfit, sans-serif'; ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(0,0,0,' + (lb.alpha * 0.8) + ')';
    ctx.fillText(lb.text, lb.x + 1, lb.y + 1);
    ctx.fillStyle = 'rgba(255,255,255,' + lb.alpha + ')';
    ctx.fillText(lb.text, lb.x, lb.y);
  }

  requestAnimationFrame(render);
}

render();
